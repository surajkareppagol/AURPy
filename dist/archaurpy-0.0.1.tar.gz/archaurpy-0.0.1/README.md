# AUR Helper Py

`AUR Helper Py` is another AUR helper for you, not full feature rich just does one thing and that is to download the correct package, for searching it uses the `Aurweb RPC interface`.

![aur_arch](https://raw.githubusercontent.com/surajkareppagol/assets-for-projects/main/aur_arch.gif)
